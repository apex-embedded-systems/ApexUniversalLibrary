Turn Word Wrap On

Enclosed are two examples for socket (TCP/IP) based connection to 2701:

2701 .net winsock demo.zip :    uses Winsock ActiveX control (from VB6) in VB.NET
2701 Class Demo.zip          :    uses preferred .NET Socket Class for the TCP/IP connection