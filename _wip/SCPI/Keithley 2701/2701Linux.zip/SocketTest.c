/* 2701 Example with Linux. */
/* This example was developed using Red Hat Linux version 7.2(Enigma), Kernel 2.4.7-10 and gedit 0.9.4 */
/* This application requires a 2701 Instrument and a 7700, 7706 or 7708 card. */

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

int main()
{
   int sockfd;
   int len;
   struct sockaddr_in address;
   int result;
   char ch ='A';
   char c[255];
   int a = 0;
   int i = 0;
   char *tmpStr;
  
   	/* create a socket for the client */
   sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
 	if(0 == sockfd)
	{
		perror("Bad Socket\n");
		exit(1);
	}  
	/* name the socket as agreed with the server */
   address.sin_family = AF_INET;
   /* enter the IP Address of the 2701 Instrument. */
   address.sin_addr.s_addr = inet_addr("10.40.11.70");
   address.sin_port = htons(1394);
   len = sizeof(address);
   
   	/* now connect our socket to the server's socket */
   result = connect(sockfd, (struct sockaddr *)&address, len);
   
   if (result == -1)
   {
      perror("Connection Error\n ");
      exit(1);
   }
   else
	{
	   printf("Connected to IP Address: 10.40.11.70 \n" );
	}
   
   /*Set the TCP_IP NODELAY option to 1 */
   setsockopt(sockfd, IPPROTO_TCP, 1, "TRUE", 1);

   /* we can now read and write via sockfd */
   /*Reset default turns the Filter off and format the data*/
   write(sockfd, "*RST;FORM:ELEM READ\r\n", strlen("*RST;FORM:ELEM READ\r\n"));
	/*Set for F Order is important. must be done first */
   write(sockfd, "UNIT:TEMP F,(@101:105)\r\n", strlen("UNIT:TEMP F,(@101:105)\r\n"));
	/*Set up the channels for temp*/
   write(sockfd, "FUNC 'TEMP', (@101:105)\r\n", strlen("FUNC 'TEMP', (@101:105)\r\n"));
	/*Config for Thermocouple*/
   write(sockfd, "TEMP:TRAN TC,(@101:105)\r\n", strlen("TEMP:TRAN TC,(@101:105)\r\n"));
	/*Config for K Couple */
   write(sockfd, "TEMP:TC:TYPE K,(@101:105)\r\n", strlen("TEMP:TC:TYPE K,(@101:105)\r\n"));
	/*Clear Buffer*/
	write(sockfd, "TRAC:CLE\r\n", strlen("TRAC:CLE\r\n"));
	/*Set number of scans*/
	write(sockfd, "TRIG:COUN 1\r\n", strlen("TRIG:COUN 1\r\n"));
	/*Set number of channels*/
	write(sockfd, "SAMP:COUN 5\r\n", strlen("SAMP:COUN 5\r\n"));
	/*Set scan list*/
	write(sockfd, "ROUT:SCAN (@101:105)\r\n", strlen("ROUT:SCAN (@101:105)\r\n"));
	/*Start scan when enabled*/
	write(sockfd, "ROUT:SCAN:TSO IMM\r\n", strlen("ROUT:SCAN:TSO IMM\r\n"));
	/*Enable scan*/
	write(sockfd, "ROUT:SCAN:LSEL INT\r\n", strlen("ROUT:SCAN:LSEL INT\r\n"));

	write(sockfd, "READ?\r\n", strlen("READ?\r\n"));

	memset(c, 0, sizeof(c));
	tmpStr = "";

	read(sockfd, (char*)c, 255);

	tmpStr = c;

	printf("Data Received in degrees Fahrenhite is:\n%s\n", tmpStr);

	printf ("Press ENTER to exit !\n");

	getchar();

   close(sockfd);

   exit(0);
}
