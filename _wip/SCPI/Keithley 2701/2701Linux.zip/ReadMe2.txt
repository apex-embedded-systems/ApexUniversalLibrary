2701 Example with Linux. 
This example was developed using Red Hat Linux version 7.2(Enigma), Kernel 2.4.7-10 and gedit 0.9.4 
This application requires a 2701 Instrument and a 7700, or 7706 or 7708 card. 

This Application requires the following Header files:
1.types.h (present under <sys/types.h>)
2.socket.h (present under <sys/socket.h>)
3.stdio.h (present under <stdio.h>)
4.in.h (present under <netinet/in.h>)
5.inet.h (present under <arpa/inet.h>)
6.unistd.h (present under <unistd.h>)

The user needs to modify the IP Address of the 2701 in the source code. 

The user needs to make sure that the IP Address, Subnet, and Gateway are set
correctly.


Note:

This example shows how to use Linux with the 2701, Keithley is prepared to support the use of the 2701 only from a windows operating system.