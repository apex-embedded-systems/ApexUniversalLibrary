'==========================================================================
' (c) 2007-2009  Total Phase, Inc.
'--------------------------------------------------------------------------
' Project : Cheetah Sample Code
' File    : eeprom.bas
'--------------------------------------------------------------------------
' Perform simple read and write operations to an SPI EEPROM device
'--------------------------------------------------------------------------
' Redistribution and use of this file in source and binary forms, with
' or without modification, are permitted.
'
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
' "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
' LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
' FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
' COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
' INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
' BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
' LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
' CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
' LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
' ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
' POSSIBILITY OF SUCH DAMAGE.
'==========================================================================
Option Strict Off
Option Explicit On 
Module eeprom


    '======================================================================
    ' CONSTANTS
    '======================================================================
    ' Should be a power of 2 for code to work
    Public Const PAGE_SIZE As Short = 32 

    Public Const PAGE_WRITE_BATCH_SIZE As Short = 32
    Public Const PAGE_WRITE_DELAY_NS As Integer = 5000000

    Public Const EEPROM_READ As Short  = 0
    Public Const EEPROM_WRITE As Short = 1
    Public Const EEPROM_ZERO As Short  = 2


    '======================================================================
    ' UTILITY FUNCTIONS
    '======================================================================
    ' Returns the system time in milliseconds.
    Public Function timeMillis() As Long
        Dim dt1 As DateTime = Now
        Dim dt2 As DateTime = New DateTime(1970, 1, 1)
        Dim ts  As TimeSpan = dt1.Subtract(dt2)
        timeMillis = (ts.Ticks / TimeSpan.TicksPerMillisecond)
    End Function

    Function zeropad(ByRef s As String, ByRef zeros As Integer) As String
        Dim i As Integer
        If Len(s) < zeros Then
            For i = 0 To zeros - 1 - Len(s)
                s = "0" & s
            Next
        End If
        zeropad = s
    End Function

    '======================================================================
    ' FUNCTIONS
    '======================================================================
    Public Sub writeMemory(ByRef handle As Integer, ByRef addr As Short, _
                           ByRef length As Short, ByRef zero As Boolean)
        Dim n, i, j, batch As Integer
        Dim count          As Short

        Dim data_out()     As Byte
        ReDim data_out(3 + PAGE_SIZE)

        Dim   noresult(0) As Byte

        ' Write to the SPI EEPROM
        '
        ' The AT25080A EEPROM has 32 byte pages.  Data can written
        ' in pages, to reduce the number of overall SPI transactions
        ' executed through the Cheetah adapter.
        n = 0
        While (n < length)
            Call CheetahApi.ch_spi_queue_clear(handle)
            Call CheetahApi.ch_spi_queue_oe(handle, 1)

            ' Send PAGE_WRITE_BATCH_SIZE number of pages to the Cheetah per
            ' batch shift.
            For i = 0 To PAGE_WRITE_BATCH_SIZE - 1
                If (n >= length) Then
                    Exit For
                End If

                ' Send write enable command
                Call CheetahApi.ch_spi_queue_ss(handle, &H1S)
                Call CheetahApi.ch_spi_queue_byte(handle, 1, &H6S)
                Call CheetahApi.ch_spi_queue_ss(handle, 0)

                ' Assemble the write command and address
                Console.Write("addr = 0x" & zeropad(Hex(addr), 4) & "; ")
                data_out(0) = &H2S
                data_out(1) = CByte((addr >> 8) And &HFFS)
                data_out(2) = CByte(addr And &HFFS)

                ' Assemble the data
                ' Do one iteration of loop before evaluating the loop condition
                j = 3
                data_out(j) = IIf(zero, 0, CByte(n))
                addr = addr + 1
                n = n + 1
                j = j + 1
                While ((n < length) And (addr And (PAGE_SIZE - 1)))
                    data_out(j) = IIf(zero, 0, CByte(n))
                    addr = addr + 1
                    n = n + 1
                    j = j + 1
                End While

                Console.WriteLine("num bytes = " & j-3)

                ' Queue the write transaction
                Call CheetahApi.ch_spi_queue_ss(handle, &H1S)
                Call CheetahApi.ch_spi_queue_array(handle, j, data_out)
                Call CheetahApi.ch_spi_queue_ss(handle, 0)

                ' Put in a wait for the write cycle time.
                Call CheetahApi.ch_spi_queue_delay_ns(handle, _
                    PAGE_WRITE_DELAY_NS)
            Next i

            ' Shift the page writes
            ' Don't need the results back from the shift
            Console.WriteLine("Shifting data")

            batch = CheetahApi.ch_spi_batch_length(handle)
            count = CheetahApi.ch_spi_batch_shift(handle, 0, noresult)
            If (count <> batch) Then
                Console.WriteLine("Expected " & batch & _
                    " bytes but only received " & count & " bytes")
                Exit Sub
            End If
            Console.WriteLine("Shift complete")
        End While
    End Sub

    Public Sub readMemory(ByRef handle As Integer, ByRef addr As Short, _
                          ByRef length As Short)
        Dim count As Integer
        Dim i     As Integer

        Dim   data_in() As Byte
        ReDim data_in(length + 3)

        Call CheetahApi.ch_spi_queue_clear(handle)
        Call CheetahApi.ch_spi_queue_oe(handle, 1)

        ' Queue the read command, address, and data
        Call CheetahApi.ch_spi_queue_ss(handle, &H1S)
        Call CheetahApi.ch_spi_queue_byte(handle, 1, &H3S)
        Call CheetahApi.ch_spi_queue_byte(handle, 1, _
            CByte((addr >> 8) And &HFFS))
        Call CheetahApi.ch_spi_queue_byte(handle, 1, CByte(addr And &HFFS))
        Call CheetahApi.ch_spi_queue_byte(handle, length, &H0S)
        Call CheetahApi.ch_spi_queue_ss(handle, 0)

        count = CheetahApi.ch_spi_batch_shift(handle, length + 3, data_in)

        If (count < 0) Then
            Console.WriteLine("error: " & CheetahApi.ch_status_string(count))

        ElseIf (count <> length + 3) Then
            Console.WriteLine("error: read " & count - 3 & _
                " bytes (expected " & length & ")")
        End If

        ' Dump the data to the screen
        Console.WriteLine("")
        Console.Write("Data read from device:")
        For i = 0 To length - 1
            If ((i And &HFS) = 0) Then
                Console.WriteLine("")
                Console.Write(zeropad(Hex(addr + i), 4) & ":  ")
            End If
            Console.Write(zeropad(Hex(data_in(i + 3) And &HFFS), 2) & " ")
            If (((i + 1) And &H7S) = 0) Then
                Console.Write(" ")
            End If
        Next i
        Console.WriteLine("")
    End Sub


    '======================================================================
    ' MAIN PROGRAM
    '======================================================================
    Public Sub eeprom_run(ByRef commandCode As Integer)
        Dim noresult(0) As Byte
        Dim port        As Integer
        Dim bitrate     As Integer
        Dim handle      As Integer

        Dim addr        As Short
        Dim length      As Short

        Dim mode        As Byte

        port     = 0    'Open Port 0 by default
        bitrate  = 16000
        mode     = 0
        length   = 64
        addr     = 0

        ' Open the device
        handle = CheetahApi.ch_open(port)
        If handle <= 0 Then
            Console.WriteLine("Unable to open Cheetah on port " & port)
            Console.WriteLine("Error code = " & handle)
            Exit Sub
        End If
        Console.WriteLine("Opened Cheetah device on port " & port)

        Dim speed As String
        If CheetahApi.ch_host_ifce_speed(handle) Then
            speed = "high speed"
        Else
            speed = "full speed"
        End If
        Console.WriteLine("Host interface is " & speed)

        ' Ensure that the SPI subsystem is configured
        Call CheetahApi.ch_spi_configure(handle, (mode / 2), mode And 1, _
            CheetahSpiBitorder.CH_SPI_BITORDER_MSB, 0)
        Console.WriteLine("SPI configuration set to mode " & mode & ", " & _
            "MSB shift, SS[2:0] active low")

        ' Power the target using the Cheetah adapter's power supply
        Call CheetahApi.ch_target_power(handle, CheetahApi.CH_TARGET_POWER_ON)
        Call CheetahApi.ch_sleep_ms(100)

        ' Set the bitrate
        bitrate = CheetahApi.ch_spi_bitrate(handle, bitrate)
        Console.WriteLine("Bitrate set to " & bitrate & " kHz")

        ' Shift a dummy byte to clear the EEPROM state
        Call CheetahApi.ch_spi_queue_clear(handle)
        Call CheetahApi.ch_spi_queue_oe(handle, 1)
        Call CheetahApi.ch_spi_queue_ss(handle, &H1S)
        Call CheetahApi.ch_spi_queue_byte(handle, 1, &H0S)
        Call CheetahApi.ch_spi_queue_ss(handle, 0)
        Call CheetahApi.ch_spi_batch_shift(handle, 0, noresult)

        ' Perform the requested operation
        If (commandCode = EEPROM_WRITE) Then
            Call writeMemory(handle, addr, length, False)
            Console.WriteLine("Wrote to EEPROM")

        ElseIf (commandCode = EEPROM_READ) Then
            Call readMemory(handle, addr, length)

        ElseIf (commandCode = EEPROM_ZERO) Then
            Call writeMemory(handle, addr, length, True)
            Console.WriteLine("Zero'd EEPROM")
        Else
            Console.WriteLine("unknown command: " & commandCode)
        End If

        'Close and exit
        Call CheetahApi.ch_close(handle)
    End Sub
End Module
