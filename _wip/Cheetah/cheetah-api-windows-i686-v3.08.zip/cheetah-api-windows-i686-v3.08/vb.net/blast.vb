'==========================================================================
' (c) 2007-2009  Total Phase, Inc.
'--------------------------------------------------------------------------
' Project : Cheetah Sample Code
' File    : blast.bas
'--------------------------------------------------------------------------
' Blast SPI data using the Cheetah host adapter
'--------------------------------------------------------------------------
' Redistribution and use of this file in source and binary forms, with
' or without modification, are permitted.
'
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
' "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
' LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
' FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
' COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
' INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
' BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
' LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
' CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
' LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
' ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
' POSSIBILITY OF SUCH DAMAGE.
'==========================================================================
Option Strict Off
Option Explicit On
Module blast


    '======================================================================
    ' CONSTANTS
    '======================================================================
	' Uncomment to show the data returned by the shifting device
	Public Const SHOW_DATA As Boolean = True
	
	'Add a delay between bytes by changing this constant (in nanoseconds)
	Public Const BYTE_DELAY As Short = 0
	
    '======================================================================
    ' UTILITY FUNCTIONS
    '======================================================================
    ' Returns the system time in milliseconds.
    Public Function timeMillis() As Long
        Dim dt1 As DateTime = Now
        Dim dt2 As DateTime = New DateTime(1970, 1, 1)
        Dim ts As TimeSpan = dt1.Subtract(dt2)
        timeMillis = (ts.Ticks / TimeSpan.TicksPerMillisecond)
    End Function

    Function zeropad(ByRef s As String, ByRef zeros As Integer) As String
        Dim i As Integer
        If Len(s) < zeros Then
            For i = 0 To zeros - 1 - Len(s)
                s = "0" & s
            Next
        End If
        zeropad = s
    End Function


    '======================================================================
    ' FUNCTIONS
    '======================================================================
    Sub blast(ByRef handle As Integer, ByRef length As Integer)
        Dim elapsed     As Double
        Dim noresult(0) As Byte

        Dim start As Long
        start = timeMillis()

        ' Queue the read sequence
        Call CheetahApi.ch_spi_queue_clear(handle)
        Call CheetahApi.ch_spi_queue_oe(handle, 1)
        Call CheetahApi.ch_spi_queue_ss(handle, 0)
        Call CheetahApi.ch_spi_queue_ss(handle, &H1S)

        Dim delay As Integer
        delay = 0
        Dim j As Integer
        For j = 0 To length - 1
            Call CheetahApi.ch_spi_queue_byte(handle, 1, j And &HFFS)
            delay = CheetahApi.ch_spi_queue_delay_ns(handle, BYTE_DELAY)
        Next j

        Console.WriteLine("Queued delay of " & delay & " ns between bytes.")

        Call CheetahApi.ch_spi_queue_ss(handle, 0)
        Call CheetahApi.ch_spi_queue_oe(handle, 0)

        elapsed = timeMillis() - start
        Console.WriteLine("Took " & VB6.Format(elapsed / 1000, "0.00") & _
            " seconds to queue the batch.")

        ' Perform the shift
        Dim batch As Integer
        batch = CheetahApi.ch_spi_batch_length(handle)
        Dim data_in() As Byte
        ReDim data_in(batch)

        start = timeMillis()
        Dim count As Integer
        count = CheetahApi.ch_spi_batch_shift(handle, batch, data_in)

        elapsed = timeMillis() - start
        Console.WriteLine("Took " & VB6.Format(elapsed / 1000, "0.00") & _
            " seconds to shift the batch.")

        If (count =  batch) Then
            Dim i As Integer
            If (SHOW_DATA) Then
                ' Output the data to the screen
                Console.WriteLine("")
                Console.Write("Data:")
                For i = 0 To length - 1
                    If ((i And &H7S) = 0) Then
                        Console.WriteLine("")
                        Console.Write(zeropad(Hex(i), 4) & ":  ")
                    End If
                    Console.Write(zeropad(Hex(i And &HFFS), 2) & "/" & _
                                  zeropad(Hex(data_in(i)), 2) & " ")
                Next i
                Console.WriteLine("")
            End If
        Else
            Console.WriteLine("Expected " & batch & _
                " bytes but only received " & count & " bytes")
        End If
    End Sub


    '======================================================================
    ' MAIN PROGRAM
    '======================================================================
    Public Sub blast_run()
        Dim port    As Integer
        Dim bitrate As Integer
        Dim handle  As Integer
        Dim length  As Integer

        Dim mode     As Byte
        Dim bitorder As Byte

        port     = 0      'Open Port 0 by default
        bitrate  = 50000
        mode     = 0
        bitorder = 0
        length   = 64

        ' Open the device
        handle = CheetahApi.ch_open(port)
        If handle <= 0 Then
            Console.WriteLine("Unable to open Cheetah on port " & port)
            Console.WriteLine("Error code = " & handle)
            Exit Sub
        End If
        Console.WriteLine("Opened Cheetah device on port " & port)

        Dim speed As String
        If CheetahApi.ch_host_ifce_speed(handle) Then
            speed = "high speed"
        Else
            speed = "full speed"
        End If
        Console.WriteLine("Host interface is " & speed)

        ' Ensure that the SPI subsystem is configured.
        Call CheetahApi.ch_spi_configure(handle, mode / 2, mode And 1, _
            (bitorder <> 0), 0)
        Console.WriteLine("SPI configuration set to mode " & mode & _
            IIf(bitorder = 0, ", MSB", ", LSB") & " shift, " & _
            "SS[2:0] active low")

        ' Power the target using the Cheetah adapter's power supply.
        Call CheetahApi.ch_target_power(handle, CheetahApi.CH_TARGET_POWER_ON)
        Call CheetahApi.ch_sleep_ms(100)

        ' Set the bitrate.
        bitrate = CheetahApi.ch_spi_bitrate(handle, bitrate)
        Console.WriteLine("Bitrate set to " & bitrate & " kHz")

        Call blast(handle, length)
        Call CheetahApi.ch_close(handle)
    End Sub
End Module
