                   Total Phase Cheetah Sample Code
                   -------------------------------

Introduction
------------
This directory contains examples that use the Cheetah Rosetta Python
language bindings.


Contents
--------
See top level EXAMPLES.txt for descriptions of each example.


Instructions
------------
1) Download Python 2.5 from:
http://www.python.org/2.5/

2) Install the Python package

3) Open a command shell and change to the examples directory

4) Type: 'python SCRIPT'
example: python detect.py
